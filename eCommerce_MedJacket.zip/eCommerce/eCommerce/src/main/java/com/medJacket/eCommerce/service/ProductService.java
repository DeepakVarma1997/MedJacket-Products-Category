package com.medJacket.eCommerce.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.medJacket.eCommerce.dao.CategoryDao;
import com.medJacket.eCommerce.dao.ProductDao;
import com.medJacket.eCommerce.model.CategoryTable;
import com.medJacket.eCommerce.model.ProductTable;

import jakarta.persistence.EntityNotFoundException;



@Service
public class ProductService {

	@Autowired
	ProductDao productDao;
	
	@Autowired
	CategoryDao categoryDao;
	
	@Transactional(readOnly = true)
	public ResponseEntity<List<ProductTable>> getAllProducts(){
		try {
			List<ProductTable> products = productDao.findAll();
			return new ResponseEntity<>(products,HttpStatus.OK);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return new ResponseEntity<List<ProductTable>>(new ArrayList<>(),HttpStatus.BAD_REQUEST);
	}

	  @Transactional
	  public ResponseEntity<ProductTable> getProductsById(Long id) { 
		  try {
	      ProductTable productId = productDao.findById(id).get(); 
	  return new ResponseEntity<ProductTable>(productId,HttpStatus.OK);
	  } 
		  catch(Exception e) {
	  e.printStackTrace(); 
	  } 
	  return new ResponseEntity<ProductTable>(HttpStatus.BAD_REQUEST); }

	@Transactional
	public ResponseEntity<String> createProduct(ProductTable producttable) {
		
		try {
			productDao.save(producttable);
			return new ResponseEntity<>("Data Saved Succesfully",HttpStatus.CREATED);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			return new ResponseEntity<>(new String(),HttpStatus.BAD_REQUEST);
	}

	@Transactional
	 public ProductTable updateProduct(ProductTable product, Long id) {
		 ProductTable existingProduct = productDao.findById(id)
	                .orElseThrow(() -> new EntityNotFoundException("Product not found with id: " + id));
	        existingProduct.setName(product.getName());
	        existingProduct.setDescription(product.getDescription());
	        existingProduct.setPrice(product.getPrice());
	        existingProduct.setCategoryId(product.getCategoryId());
	        existingProduct.setUpdatedAt(LocalDateTime.now());
	        return productDao.save(existingProduct);
	    }
	 
	 @Transactional
	 public ResponseEntity<String> deleteProduct(Long id) {
		 try {
			 productDao.deleteById(id);
				return new ResponseEntity<>("Data Deleted Succesfully",HttpStatus.OK);
				}
				catch(Exception e) {
					e.printStackTrace();
				}
				return new ResponseEntity<>(new String(),HttpStatus.BAD_REQUEST);
		 
	    }

}
