package com.medJacket.eCommerce.dao;

import java.util.List;

import org.apache.el.stream.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.medJacket.eCommerce.model.CategoryTable;
import com.medJacket.eCommerce.model.ProductTable;

@Repository
public interface ProductDao extends JpaRepository<ProductTable, Long>{

	//List<ProductTable> findByCategoryId(Long categoryId);
}
