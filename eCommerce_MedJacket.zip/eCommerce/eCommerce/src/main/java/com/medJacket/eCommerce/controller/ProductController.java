package com.medJacket.eCommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.medJacket.eCommerce.model.ProductTable;
import com.medJacket.eCommerce.service.CategoryService;
import com.medJacket.eCommerce.service.ProductService;

@RestController
@RequestMapping("products")
public class ProductController {

			@Autowired
			ProductService productService;
			
			@Autowired
			CategoryService categoryService;
			
		    @GetMapping("allProducts")
		    @ResponseBody
		    public ResponseEntity<List<ProductTable>> getAllProducts(){
		    	return productService.getAllProducts();
		    }

	
		   @GetMapping("/{id}")
		   @ResponseBody
		   public ResponseEntity<ProductTable> getProductsById(@PathVariable Long id){ 
			 
			   return productService.getProductsById(id); 
		   }
		   
		   
		   @PostMapping("add")
			  public ResponseEntity<String> createProduct(@RequestBody ProductTable producttable){
				  
			  return productService.createProduct(producttable);
			}
		   
		   @PutMapping("/{id}")
		    public ResponseEntity<ProductTable> updateProduct(@PathVariable Long id, @RequestBody ProductTable product) {
			   ProductTable updatedProduct = productService.updateProduct(product, id);
		        return ResponseEntity.ok(updatedProduct);
		    }
		   
		   @DeleteMapping("/{id}")
		    public ResponseEntity<String> deleteProduct(@PathVariable Long id) {
			   return  productService.deleteProduct(id);
		    }
}
