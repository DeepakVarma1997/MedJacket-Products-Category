package com.medJacket.eCommerce.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.medJacket.eCommerce.model.CategoryTable;

@Repository
public interface CategoryDao extends JpaRepository<CategoryTable, Long>{
	@Query(value="select * from category_table q where q.name=:name",nativeQuery=true)
	List<CategoryTable>  findByName(String name);

}
