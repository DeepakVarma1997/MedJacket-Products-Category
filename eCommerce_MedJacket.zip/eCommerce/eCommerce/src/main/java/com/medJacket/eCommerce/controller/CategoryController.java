package com.medJacket.eCommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.medJacket.eCommerce.model.CategoryTable;
import com.medJacket.eCommerce.service.CategoryService;

@RestController
@RequestMapping("category")
public class CategoryController {
	
	@Autowired
	CategoryService categoryService;
	
	@GetMapping("allCategory")
	@ResponseBody
	public ResponseEntity<List<CategoryTable>> getAllCategory(){
		return categoryService.getAllCategory();
	}
	
	@GetMapping("/{name}")
    public ResponseEntity<List<CategoryTable>> getCategoryByName(@PathVariable String name){    	
    	return categoryService.getCategoryByName(name);
      }
	
    @PostMapping("add")
    public ResponseEntity<String> createCategory(@RequestBody CategoryTable categorytable){
    	return categoryService.createCategory(categorytable);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<CategoryTable> updateCategory(@PathVariable Long id, @RequestBody CategoryTable category) {
    	CategoryTable updatedCategory = categoryService.updateCategory(id, category);
        return ResponseEntity.ok(updatedCategory);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCategory(@PathVariable Long id) {
        return categoryService.deleteCategory(id);
        
    }
}
