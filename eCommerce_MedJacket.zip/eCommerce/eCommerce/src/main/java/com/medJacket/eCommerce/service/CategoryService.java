package com.medJacket.eCommerce.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.medJacket.eCommerce.dao.CategoryDao;
import com.medJacket.eCommerce.model.CategoryTable;

import jakarta.persistence.EntityNotFoundException;



@Service
public class CategoryService {
	
	@Autowired
	CategoryDao categoryDao;

	@Transactional
	public ResponseEntity<List<CategoryTable>> getAllCategory() {
		try {
			List<CategoryTable> category = categoryDao.findAll();
			return new ResponseEntity<>(category,HttpStatus.OK);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return new ResponseEntity<List<CategoryTable>>(new ArrayList<>(),HttpStatus.BAD_REQUEST);
	}	
	
	@Transactional
	public ResponseEntity<List<CategoryTable>> getCategoryByName(String name) {
		try {
			List<CategoryTable> categoryByName = categoryDao.findByName(name);
			return new ResponseEntity<>(categoryByName,HttpStatus.OK);
		}
		catch(Exception e) 
		{
			e.printStackTrace();
		}
		return new ResponseEntity<List<CategoryTable>>(new ArrayList<>(),HttpStatus.BAD_REQUEST);
	}

	@Transactional
	public ResponseEntity<String> createCategory(CategoryTable categorytable) {
		try {
			categoryDao.save(categorytable);
			return new ResponseEntity<>("Data Saved Succesfully",HttpStatus.OK);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return new ResponseEntity<>(new String(),HttpStatus.BAD_REQUEST);
	}
	 
	@Transactional
    public CategoryTable updateCategory(Long id, CategoryTable category) {
		CategoryTable existingCategory = categoryDao.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Category not found with id: " + id));
        existingCategory.setName(category.getName());
        existingCategory.setDescription(category.getDescription());
        return categoryDao.save(existingCategory);
    }

    @Transactional
    public ResponseEntity<String> deleteCategory(Long id) {
    	 try {
    		 categoryDao.deleteById(id);
				return new ResponseEntity<>("Data Deleted Succesfully",HttpStatus.OK);
				}
				catch(Exception e) {
					e.printStackTrace();
				}
				return new ResponseEntity<>(new String(),HttpStatus.BAD_REQUEST);
		 
	    }
    
  
	}


